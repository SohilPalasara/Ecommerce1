package admin;

interface OrderMethod {
    public void admin();
    public void customer();
}
