package costomer;

public interface Method {
   public void signup();
    public void login();
    public void update();
    public void logout();
}
