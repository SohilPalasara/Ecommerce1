package userPackage;

public interface users {

    void signup();

    void login();

//        void password();

    void update();

    void logout();

//    void view();


}